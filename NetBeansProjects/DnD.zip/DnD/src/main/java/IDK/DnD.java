package IDK;

import IGU.Grafica;

public class DnD {
    
    public static void main(String[] args) {
        //crea unan ventana
        Grafica formClaves = new Grafica();
        //hace visible la ventana
        formClaves.setVisible(true);
        //genera la ventana centrada
        formClaves.setLocationRelativeTo(null);
    }
}
