package logica;

// En un metodo abstracto asignamos las acciones que va a cometer el elfo, pero no como las hará.
public interface Elfo {
    String atacarConArco(Personaje objetivo);
}
