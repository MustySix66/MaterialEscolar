package logica;

import igu.VentanaClaves;

public class Claves {

    public static void main(String[] args) {
        //crea unan ventana
        VentanaClaves formClaves = new VentanaClaves();
        //hace visible la ventana
        formClaves.setVisible(true);
        //genera la ventana centrada
        formClaves.setLocationRelativeTo(null);
    }
}


