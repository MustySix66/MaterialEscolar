package Logica;

public class Formulas {
    protected double Valor1,Valor2;
    protected String texto1,texto2;

    public Formulas() {
    }

    public Formulas(double v1, double v2, String t1, String t2) {
        this.Valor1 = v1;
        this.Valor2 = v2;
        this.texto1 = t1;
        this.texto2 = t2;
    }
    
    public String formula(double valor1, String tipoR){
        // Aqui no va nada
        return null;
    }
}
