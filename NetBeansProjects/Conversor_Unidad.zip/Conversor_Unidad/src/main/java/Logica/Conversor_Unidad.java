package Logica;

import GUI.Interfaz;

public class Conversor_Unidad {

    public static void main(String[] args) {
        //crea unan ventana
        Interfaz formClaves = new Interfaz();
        //hace visible la ventana
        formClaves.setVisible(true);
        //genera la ventana centrada
        formClaves.setLocationRelativeTo(null);

        // hola github
    }
}
