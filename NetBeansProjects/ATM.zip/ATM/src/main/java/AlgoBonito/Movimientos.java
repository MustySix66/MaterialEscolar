
package AlgoBonito;

public interface Movimientos {
    // metodos abstractos que se sobre escribirán luego
    public String retiro(double monto);
    public String deposito(double monto);
    public String consultarSaldo();
    
}