/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package AlgoBonito;

import IGU.Ventana;

/**
 *
 * @author kevin
 */
public class ATM {

    public static void main(String[] args) {
        // abre una ventana donde se mostrarán los componentes
        Ventana ventana = new Ventana();
        ventana.setVisible(true);
    }
}